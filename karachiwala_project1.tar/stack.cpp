#include <iostream>
#include <string>
#include "tree.cpp"

using namespace std;

struct stackNode
{
    tree *t;
    struct stackNode *next;
};

class stack
{    
    public:
    struct stackNode *top;

    stack() 
    {    
        top = NULL;
    }

    void push(tree *t);
    tree *pop();
};

void stack::push(tree *t)
{
    struct stackNode *newNode;
 
    newNode = new stackNode;
    newNode->t = t;
    newNode->next = NULL;
    if(top!=NULL)
        newNode->next = top;
    top=newNode;
}

tree *stack::pop()
{
    struct stackNode *temp;
    tree *t;
    if(top == NULL)
    {
        cout<<"\nError Stack underflow";
    }
    temp = top;
    top = top->next;
    t = temp->t;
    delete temp;            //return the tree of this node
    return t;
}
