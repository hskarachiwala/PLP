#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cstdlib>
#include "stack.cpp"

using namespace std;

class parser
{
    public:

        string next_token;  
        stack *s;
        ifstream fin;           //file pointer kept global
            
        void Read(string token);
        void buildTree(string token, int n);
        void preOrder(string level,treeNode* root);
        void scanNextToken();
        bool isOperator(string token);
        bool isIdentifier(string token);
        bool isKeyword(string token);
        bool isRnValue(string token);
        bool isPunction(string token);
        int parse(char *filename);

        //all grammar
        void E();
        void Ew();
        void T();
        void Ta();
        void Tc();
        void B();
        void Bt();
        void Bs();
        void Bp();
        void A();
        void At();
        void Af();
        void Ap();
        void R();
        void Rn();
        void D();
        void Da();
        void Dr();
        void Db();
        void Vb();
        int Vl();

        parser(string fileLocation)             //make file accessible to the parser
        {
            fin.open(fileLocation.c_str());
            if (!fin.good())
            {
                cout << "File could not be opened\n";
                exit(1);
            }
            scanNextToken();        //reading one initial token
        }
};


int parser::parse(char *filename)
{
    E();
    fin.close();
}

void parser::scanNextToken()        //gets the next token in the program
{
    bool firstEncountered = false;       //tracks if first char of current token has already been encountered
    bool scanningInt = false;
    string currentToken = "";
    char c = '\0';

    while ( !fin.eof() ) 
    {
        int eof = fin.peek();
        if (eof == EOF)             //encountering eof issue
        {
            if (fin.eof())
            {
                next_token = "eol";
                return;
            }
        }

        fin.get(c);
        if(isalnum(c))          //first character is alphanumeric
        {
            if(!firstEncountered)     
            {
                firstEncountered = true;
                if(isdigit(c))           //this will be an integer                
                {    
                    scanningInt = true;
                    currentToken = currentToken + c;        //add digit and read next character
                    continue;    
                }
                else
                {
                    currentToken = currentToken + c;        //begin reading string    
                    continue;
                }
            }
            else                            //first char has been encountered
            {
                if(scanningInt)         //currently scanning int 
                { 
                    if(isdigit(c))
                    {
                        currentToken = currentToken + c;    //add to current token 
                        continue;   
                    }  
                    else                                        //character appeared in middle
                    {
                        cout << "Invalid character encountered within a digit";
                        exit(-1);
                    }
                }
                else        //scan string
                {
                    currentToken = currentToken + c;
                    continue;
                }
            }
        }
        if(c == '_')
        {
            if(firstEncountered)
            {
                currentToken = currentToken + c;
                continue;
            }
            else
            {
                //something when _ appears as operator???  
            }
        }

        if(c =='=')                         //equals sign
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = "=";
                return;    
            }    
        }
        
        if( c==' ' || c=='\n' || c=='\t')    
        {
            if(!firstEncountered)       //ignore white spaces if nothing is read yet
                continue;
            else
            {
                next_token = currentToken;      //return what is made so far
                return;       
            }
        }

        if(c=='+' || c=='-')             //could be addition or subtraction
        {
            if(c=='+')                  //is addition
            {
                if(firstEncountered)        // if some token is currently being scanned
                {
                    fin.unget();
                    next_token = currentToken;
                    return;
                }
                else            
                {
                    next_token = c;
                    return;
                }    
            }
            else
            {
                if(firstEncountered)        // if some token is currently being scanned
                {
                    fin.unget();
                    next_token = currentToken;
                    return;
                }
                next_token = c;
                fin.get(c);     //get next character to check for ->
                if(c=='>')     //is conditional
                {
                    next_token = next_token + c;
                    return;
                }
                else            //subtract
                {
                    fin.unget();        //unget the char for  check
                    next_token = "-";
                    return;
                }

            }
            
        }

        if(c=='>' || c=='<')             //could be gr or ge
        {
            if(firstEncountered)        // if some token is currently being scanned
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            currentToken = currentToken + c;    //add the first
            fin.get(c);     //get next character to check for =
            if(c=='=')     //add
            {
                currentToken = currentToken + c;
                next_token = currentToken;
                return;
            }
            else            //only one sign
            {
                fin.unget();        
                next_token = currentToken;
                return;
            }
        }

        if(c=='*')             //could be multiply or exponent
        {
            if(firstEncountered)        // if some token is currently being scanned
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            fin.get(c);     //get next character to check for *
            if(c=='*')     //is exponent
            {
                next_token = currentToken + c;
                return;
            }
            else            //multiply
            {
                fin.unget();        //unget the char for check
                next_token = "*";
                return;
            }
        }

        if(c=='/')             //could be divide or comment
        {
            if(firstEncountered)        // if some token is currently being scanned
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            fin.get(c);     //get next character to check for comment
            if(c=='/')     //is comment
            {
                while(c!='\n')
                    fin.get(c);
                continue;
            }
            else            //divide
            {
                fin.unget();        //unget the char for comment check
                next_token = "/";
                return;
            }
        }
        
        if(c=='\'')            //beginning of string read it in 
        {
            do
            {
                currentToken = currentToken + c;
                fin.get(c);
            }while(c!='\'');
            currentToken = currentToken + '\'';     //adding the closing comma that will be missed
            next_token = currentToken;
            return;    
        }
        
        if(c=='(')             //opening bracket will always be a token
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = "(";
                return;
            }
        }
        
        if(c==')')             //closing bracket will always be a token
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = ")";
                return;
            }
        }

        if(c==',')                  //same procedures for all characters could be refactored??
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = ",";
                return;
            }
        }

        if(c=='|')
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = "|";
                return;
            }
        }

        if( c=='.')
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = ".";
                return;
            }
        }
        if( c=='@')
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = "@";
                return;
            }
        }
        if( c=='&')
        {
            if(firstEncountered)
            {
                fin.unget();
                next_token = currentToken;
                return;
            }
            else
            {
                next_token = "&";
                return;
            }
        }
    }
}


bool parser::isIdentifier(string token)         //check if it is a new function name or variable name
{
    if(isKeyword(token) || isRnValue(token) || isOperator(token) || isPunction(token) )
        return false;

    return true;
}

bool parser::isKeyword(string input)
{
    string keywords[] = {"let", "in", "fn", "where", "aug", "within", "and" , "eq", "ge", "gr", "ls", "le" ,"eq" , "ne", "not", "or","rec"};
    int n = sizeof(keywords)/sizeof(keywords[0]);
    for(int i=0;i<n;i++)
    {
        if(input.compare(keywords[i])==0)
            return true;
    }
    return false;
}

bool parser::isPunction(string input)
{
    string punctions[] = {"(", ")", ",", ";" , "eol" };
    int n = sizeof(punctions)/sizeof(punctions[0]);
    for(int i=0;i<n;i++)
    {
        if(input.compare(punctions[i])==0)
            return true;
    }
    return false;
}

bool parser::isOperator(string input)
{
    string operators[] = {"+", "-", "*", "<", ">", "&", ".", "@", "/", ":", "=", "~", "|", "$", "!", "#", "%", "^", 
                            "[", "]", "{", "}" ,"\"" , "'", "?", "->" };

    int n = sizeof(operators)/sizeof(operators[0]);

    for(int i=0;i<n;i++)
    {
        if(input.compare(operators[i])==0)
            return true;
    }
    return false;
}

bool parser::isRnValue(string input)            //For the Rn grammar rule
{
    string rnValues[] = {"true","false","nil","dummy"};
    int n = sizeof(rnValues)/sizeof(rnValues[0]);
    for(int i=0;i<n;i++)
    {
        if(input.compare(rnValues[i])==0)
            return true;
    }
    return false;
}

void parser::buildTree(string keyword,int n)
{
    if(n==0)                    //create a new tree with 0 children and push
    {
        tree *t = new tree;
        t->root->keyword = keyword;
        t->root->leftChild = NULL;      
        t->root->sibling = NULL;
        s->push(t);
    }
    else
    {
        tree *t = new tree;                                 //create keyword root node
        t->root->keyword = keyword;
        t->root->leftChild = NULL;      
        t->root->sibling = NULL;
        
        int count = n;
        int i=0;
        tree *childList[n];
        while(count!=0)                         //pop from stack those many times
        {
            childList[i++] = s->pop();
            count--;
        }

        struct treeNode *tail;
        t->root->leftChild = (childList[n-1])->root;    //make sibling list in reverse order
        tail = t->root->leftChild;

        for(i=n-2;i>=0;i--)     //from second last in array
        {
            tail->sibling = (childList[i])->root;
            tail = tail->sibling;
        }

        s->push(t);                       //push the new tree back in
    }
}

void parser::Read(string token)     //read method that will be one ahead
{
    if(token == "eol")
    {
        return;
    }
    if (token.compare(next_token) != 0)
    {
        cout << "Incorrect syntax found at " << next_token;
        exit(0);
    }
    if(isIdentifier(next_token))    //build a leaf for identifier
    {
        if( isdigit(next_token.at(0)) )
            buildTree("<INT:" + token + ">",0);
        else
        {
            if(next_token.at(0)=='\'')
                buildTree("<STR:" + token + ">",0);
            else
                buildTree("<ID:" + token + ">",0);    
        }
        scanNextToken();
    }
    else if(isRnValue(next_token))
    {
        buildTree("<" + token + ">",0);
        scanNextToken();
    }
    else                        //move to next
    {
        scanNextToken();
    }
}

// All grammar rule methods

void parser::E()
{    
    if(next_token.compare("let")==0)
    {
            Read("let");
            D();
            Read("in");
            E();
            buildTree("let",2);   
    }
    else if(next_token.compare("fn")==0)
    {
            Read("fn");
            int n=0;
            do
            {
                Vb();
                n++;
            }while(isIdentifier(next_token) || next_token.compare("(")==0);
            Read(".");
            E();
            buildTree("lambda",n+1);
    }
    else
    {
            Ew();
    }
}

void parser::Ew()
{
    T();
    if(next_token.compare("where")==0)
    {
        Read("where");
        Dr();
        buildTree("where",2);
    }  
}

void parser::T()
{
    Ta();
    int n=1;
    while(next_token.compare(",")==0)
    {
        Read(",");
        Ta();
        n++;
    }
    if(n>1)
    {
        buildTree("tau",n);
    }

}

void parser::Ta()
{
    Tc();
    while(next_token.compare("aug")==0)
    {
        Read("aug");
        Tc();
        buildTree("aug",2);
    }
}

void parser::Tc()
{
    B();
    if(next_token.compare("->")==0)
    {
        Read("->");
        Tc();
        Read("|");
        Tc();
        buildTree("->",3);
    }

}

void parser::B()
{
    Bt();
    while(next_token.compare("or")==0)
    {
        Read("or");
        Bt();
        buildTree("or",2);
    }    
}

void parser::Bt()
{
    Bs();
    while(next_token.compare("&")==0)
    {
        Read("&");
        Bs();
        buildTree("&",2);
    }
}

void parser::Bs()
{
    if(next_token.compare("not")==0)
    {
        Read("not");
        Bp();
        buildTree("not",1);
    }
    else
        Bp();
}

void parser::Bp()
{
    A();

    if(next_token.compare("gr")==0 || next_token.compare(">")==0)
    {
        Read(next_token);
        A();
        buildTree("gr",2);    
    }
    else if(next_token.compare("ge")==0 || next_token.compare(">=")==0)
    {
        Read(next_token);
        A();
        buildTree("ge",2);    
    }
    else if(next_token.compare("ls")==0 || next_token.compare("<")==0)
    {
        Read(next_token);
        A();
        buildTree("ls",2);    
    }
    else if(next_token.compare("le")==0 || next_token.compare("<=")==0)
    {
        Read(next_token);
        A();
        buildTree("le",2);    
    }
    else if(next_token.compare("eq")==0 )
    {
        Read(next_token);
        A();
        buildTree("eq",2);    
    }
    else if(next_token.compare("ne")==0 )
    {
        Read(next_token);
        A();
        buildTree("ne",2);    
    }    
}

void parser::A()
{
    if(next_token.compare("-")==0 )
    {
        Read("-");
        At();
        buildTree("neg",1);    
    }
    else if(next_token.compare("+")==0)
    {
        Read("+");
        At();    
    }
    else
    {
        At();
    }

    while(next_token.compare("+")==0 || next_token.compare("-")==0 )
    {
        string temp = next_token;
        Read(next_token);
        At();
        buildTree(temp,2);
    }
}

void parser::At()
{
    Af();
    while(next_token.compare("*")==0 || next_token.compare("/")==0)
    {
        string temp = next_token;
        Read(next_token);
        Af();
        buildTree(temp,2);
    }
}

void parser::Af()
{
    Ap();
    if(next_token.compare("**")==0)
    {
        Read("**");
        Af();
        buildTree("**",2);
    }
}

void parser::Ap()
{
    R();
    while(next_token.compare("@")==0)
    {
        Read("@");
        Read(next_token);   //read identifier
        R();
        buildTree("@",3);
    }
}

void parser::R()
{
    Rn();
    while( isRnValue(next_token) || isIdentifier(next_token) || next_token == "(" )        //is next token one of the Rn terminals
    {
        Rn();
        buildTree("gamma",2);
    }
}

void parser::Rn()
{
    if(isIdentifier(next_token) || isRnValue(next_token))
    {
        Read(next_token);
    }
    else if(next_token=="(")
    {
      Read("(");
      E();       
      Read(")");
    }
}

void parser::D()
{
    Da();
    if(next_token.compare("within")==0)
    {
        Read("within");
        Da();
        buildTree("within",2);
    }
}

void parser::Da()
{
    Dr();
    int n=1;
    while(next_token.compare("and")==0)
    {
        Read("and");
        Dr();
        n++;
    }
    if(n>1)
    {
        buildTree("and",n);
    }
}

void parser::Dr()
{
    if(next_token.compare("rec")==0)
    {
        Read("rec");
        Db();
        buildTree("rec",1);
    }
    else
        Db();
}

void parser::Db()
{
    if(next_token.compare("(")==0)
    {
        Read("(");
        D();
        Read(")");
    }
    else if(isIdentifier(next_token))
    {
        Read(next_token);
        int n=1;
        if(next_token=="=")
        {
            Read("=");
            E();
            buildTree("=",2);
        }
        else if(next_token==",")
        {
            n = n + Vl();
            buildTree(",",n);
            Read("=");
            E();
            buildTree("=",2);
        }
        else if (next_token=="(" || isIdentifier(next_token))
        {
            while(next_token=="(" || isIdentifier(next_token))
            {
                Vb();
                n++;
            }
            Read("=");
            E();
            buildTree("function_form",n+1);
        }
    }
}

void parser::Vb()
{
    if(isIdentifier(next_token))
        Read(next_token);
    else if(next_token.compare("(")==0)
    {
        Read("(");
        if(next_token.compare(")")==0)
        {
            Read(")");
            buildTree("()",0);
        }
        else
        {
            if(isIdentifier(next_token))
            {
                Read(next_token);
                int n=1;
                if(next_token==",")
                {
                    n = n + Vl();
                    buildTree(",",n);
                }
            }
            Read(")");
        }
    }
}

int parser::Vl()
{
    int n=0;
    if(next_token.compare(",")==0)
    {
        do
        {
            Read(",");
            if(isIdentifier(next_token))
            {
                Read(next_token);
                n++;
            }
            else
            {
                cout<<"Invalid character encountered";
                exit(1);    
            }
        }while(next_token.compare(",")==0);
    }
    return n;
}

void parser::preOrder(string level,treeNode* root)
{
    cout << level << root->keyword <<"\n";
    if( root->leftChild != NULL )
      preOrder( level + "." , root->leftChild);
    if(root->sibling!=NULL)
      preOrder(level,root->sibling);
}

int main(int argc, char *argv[])
{
    if(argc==1)             // no output whatsoever
        exit(1);
    if(argc==2)
    {
        cout << "Invalid parameters\n";
        exit(1);
    }

    if(argc>4)           // if command line param are invalid
    {
        cout << "Too many arguments specified";
        exit(1);    
    }   

    string param1,param2,fileLocation;      //if 4 params are there we might have list and ast
    if(argc==4)
    {
        param1 = argv[1];
        param2 = argv[2];
        fileLocation = argv[3];
    }
    else                                // only have ast
    {
        param1 = argv[1];
        if( param1 != "-ast" )
        {
            cout << "Invalid parameter -ast is required";
            exit(1);
        }
        fileLocation = argv[2];   
    }

    if( param1 == "-l" )        //print out the file optional
    {
        string inputLine;
        ifstream fin;
        fin.open(fileLocation.c_str());
        if (fin.good())
        {
            while ( getline (fin,inputLine) )
                cout << inputLine << '\n';
            fin.close();
        }
        else 
        {
            cout << "Could not open file"; 
            exit(1);
        }
    }


    parser *p = new parser(fileLocation);               //parser
    stack *s = new stack;                               //stack for it
    p->s = s;

    int err = p->parse(argv[0]);             //if some error is returned from parse
    if(err<0)
        return err;

    tree *t = s->pop();
    p->preOrder("",t->root);
    delete s;
    delete p;

    return 0;
}