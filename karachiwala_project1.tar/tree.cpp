#include <iostream>
#include <string>

using namespace std;

struct treeNode
{
    string keyword;
    struct treeNode *sibling;
    struct treeNode *leftChild;
};

class tree
{    
    public:
    struct treeNode *root;

    tree() 
    {       
        root = new treeNode;
    }

};


